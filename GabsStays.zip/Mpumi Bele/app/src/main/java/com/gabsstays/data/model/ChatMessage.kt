package com.gabsstays.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listingId: Int, // The listing this chat is about
    val senderId: Int, // User ID of sender
    val receiverId: Int, // User ID of receiver
    val messageText: String,
    val timestamp: Long // System.currentTimeMillis()
)
