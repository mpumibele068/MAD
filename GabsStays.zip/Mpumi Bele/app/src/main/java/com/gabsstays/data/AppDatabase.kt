package com.gabsstays.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.gabsstays.data.dao.ChatDao
import com.gabsstays.data.dao.ListingDao
import com.gabsstays.data.dao.ReservationDao
import com.gabsstays.data.dao.UserDao
import com.gabsstays.data.model.ChatMessage
import com.gabsstays.data.model.Listing
import com.gabsstays.data.model.Reservation
import com.gabsstays.data.model.User

@Database(
    entities = [User::class, Listing::class, Reservation::class, ChatMessage::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun reservationDao(): ReservationDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gabsstays_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
