package com.gabsstays.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.gabsstays.data.model.Listing

@Dao
interface ListingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertListing(listing: Listing): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertListings(listings: List<Listing>)

    @Update
    fun updateListing(listing: Listing): Int

    @Query("SELECT * FROM listings ORDER BY id DESC")
    fun getAllListings(): List<Listing>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    fun getListingById(id: Int): Listing?

    @Query("SELECT COUNT(*) FROM listings")
    fun getListingsCount(): Int
}
