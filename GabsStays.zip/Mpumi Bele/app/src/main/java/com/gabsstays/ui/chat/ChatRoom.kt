package com.gabsstays.ui.chat

data class ChatRoom(
    val listingId: Int,
    val landlordId: Int,
    val landlordName: String,
    val propertyTitle: String,
    val lastMessageText: String,
    val timestamp: Long
)
