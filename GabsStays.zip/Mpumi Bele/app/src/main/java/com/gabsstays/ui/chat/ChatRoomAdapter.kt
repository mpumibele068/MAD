package com.gabsstays.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gabsstays.databinding.ItemChatRoomBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatRoomAdapter(private val onClick: (ChatRoom) -> Unit) :
    RecyclerView.Adapter<ChatRoomAdapter.ChatRoomViewHolder>() {

    private var roomList = listOf<ChatRoom>()

    fun submitList(list: List<ChatRoom>) {
        roomList = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatRoomViewHolder {
        val binding = ItemChatRoomBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ChatRoomViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChatRoomViewHolder, position: Int) {
        holder.bind(roomList[position])
    }

    override fun getItemCount(): Int = roomList.size

    inner class ChatRoomViewHolder(private val binding: ItemChatRoomBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(room: ChatRoom) {
            binding.tvRoomName.text = room.landlordName
            binding.tvRoomProperty.text = room.propertyTitle
            binding.tvRoomLastMsg.text = room.lastMessageText

            val sdf = SimpleDateFormat("HH:mm a", Locale.getDefault())
            binding.tvRoomTime.text = sdf.format(Date(room.timestamp))

            binding.root.setOnClickListener {
                onClick(room)
            }
        }
    }
}
