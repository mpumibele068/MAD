package com.gabsstays.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val listingId: Int,
    val studentId: Int,
    val referenceNumber: String, // e.g. GABS-XXXX-STAY
    val paymentMethod: String, // e.g. Simulated Mobile Money
    val transactionTime: String, // format "Today, 14:32 PM" or similar
    val totalPaid: Int // in BWP
)
