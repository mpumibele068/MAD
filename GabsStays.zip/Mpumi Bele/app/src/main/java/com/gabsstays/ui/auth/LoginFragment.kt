package com.gabsstays.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.databinding.FragmentLoginBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up Test Account quick-fill for UB evaluator to test quickly
        binding.etEmail.setText("kgosi@ub.ac.bw")
        binding.etPassword.setText("password")

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Database query in background thread
            val database = AppDatabase.getDatabase(requireContext())
            CoroutineScope(Dispatchers.IO).launch {
                val user = database.userDao().getUserByEmail(email)
                withContext(Dispatchers.Main) {
                    if (user != null && user.password == password) {
                        MainActivity.currentUserId = user.id
                        MainActivity.currentUserRole = user.role
                        MainActivity.currentUserName = user.fullName
                        
                        Toast.makeText(context, "Welcome back, ${user.fullName}!", Toast.LENGTH_SHORT).show()
                        findNavController().navigate(R.id.action_loginFragment_to_listingsFragment)
                    } else {
                        Toast.makeText(context, "Invalid email or password", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        binding.tvCreateProfile.setOnClickListener {
            findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }

        binding.tvContinueGuest.setOnClickListener {
            MainActivity.currentUserId = -1
            MainActivity.currentUserRole = "Guest"
            MainActivity.currentUserName = "Guest Student"
            Toast.makeText(context, "Entering as Guest", Toast.LENGTH_SHORT).show()
            findNavController().navigate(R.id.action_loginFragment_to_listingsFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
