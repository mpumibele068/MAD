package com.gabsstays.ui.filters

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.User
import com.gabsstays.databinding.FragmentFiltersBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class FiltersFragment : Fragment() {

    private var _binding: FragmentFiltersBinding? = null
    private val binding get() = _binding!!

    private var currentUser: User? = null
    private val selectedLocations = mutableSetOf<String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFiltersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnFiltersBack.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.btnFiltersMenu.setOnClickListener {
            Toast.makeText(context, "Preferences Menu", Toast.LENGTH_SHORT).show()
        }

        setupDateSelector()
        setupAreaChips()
        setupSliderAndAlerts()
        loadPreferences()

        binding.btnSavePreferences.setOnClickListener {
            savePreferences()
        }
    }

    private fun loadPreferences() {
        if (MainActivity.currentUserId == -1) {
            // Guest Student default state
            selectedLocations.addAll(listOf("Tlokweng", "G-West"))
            updateAreaChipStyles()
            updateFooterText()
            return
        }

        val database = AppDatabase.getDatabase(requireContext())
        CoroutineScope(Dispatchers.IO).launch {
            val user = database.userDao().getUserById(MainActivity.currentUserId)
            currentUser = user

            withContext(Dispatchers.Main) {
                if (user != null) {
                    // Load budget min/max
                    binding.budgetSlider.values = listOf(user.budgetMin.toFloat(), user.budgetMax.toFloat())
                    binding.tvMinBudget.text = "P ${user.budgetMin}"
                    binding.tvMaxBudget.text = "P ${user.budgetMax}"
                    binding.tvLimitBadge.text = "BWP ${user.budgetMax} Limit"

                    // Load date
                    binding.tvMoveInDate.text = user.moveInDate

                    // Load locations
                    selectedLocations.clear()
                    if (user.preferredLocations.isNotEmpty()) {
                        selectedLocations.addAll(user.preferredLocations.split(",").map { it.trim() })
                    }
                    updateAreaChipStyles()

                    // Load Smart alerts toggle
                    binding.switchSmartAlerts.isChecked = user.smartAlertsEnabled

                    updateFooterText()
                }
            }
        }
    }

    private fun setupDateSelector() {
        binding.btnDatePicker.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                requireContext(),
                { _, selYear, selMonth, selDay ->
                    val monthStr = if (selMonth + 1 < 10) "0${selMonth + 1}" else "${selMonth + 1}"
                    val dayStr = if (selDay < 10) "0$selDay" else "$selDay"
                    binding.tvMoveInDate.text = "$selYear-$monthStr-$dayStr"
                },
                year, month, day
            )
            datePickerDialog.show()
        }
    }

    private fun setupAreaChips() {
        val chipViews = listOf(
            binding.chipTlokweng to "Tlokweng",
            binding.chipGwest to "G-West",
            binding.chipPhase2 to "Phase 2",
            binding.chipVillage to "Village",
            binding.chipBroadhurst to "Broadhurst",
            binding.chipBlock6 to "Block 6",
            binding.chipMmaraka to "Mmaraka",
            binding.chipNotwane to "Notwane"
        )

        for ((chipView, name) in chipViews) {
            chipView.setOnClickListener {
                if (selectedLocations.contains(name)) {
                    selectedLocations.remove(name)
                } else {
                    selectedLocations.add(name)
                }
                updateAreaChipStyles()
                updateFooterText()
            }
        }
    }

    private fun updateAreaChipStyles() {
        val chips = listOf(
            binding.chipTlokweng to "Tlokweng",
            binding.chipGwest to "G-West",
            binding.chipPhase2 to "Phase 2",
            binding.chipVillage to "Village",
            binding.chipBroadhurst to "Broadhurst",
            binding.chipBlock6 to "Block 6",
            binding.chipMmaraka to "Mmaraka",
            binding.chipNotwane to "Notwane"
        )

        for ((view, name) in chips) {
            if (selectedLocations.contains(name)) {
                view.setBackgroundResource(R.drawable.bg_role_selected)
                view.setTextColor(ContextCompat.getColor(requireContext(), R.color.primary_dark))
                view.text = "$name ✓"
            } else {
                view.setBackgroundResource(R.drawable.bg_role_unselected)
                view.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
                view.text = name
            }
        }
    }

    private fun setupSliderAndAlerts() {
        binding.budgetSlider.addOnChangeListener { slider, _, _ ->
            val values = slider.values
            val min = values[0].toInt()
            val max = values[1].toInt()

            binding.tvMinBudget.text = "P $min"
            binding.tvMaxBudget.text = "P $max"
            binding.tvLimitBadge.text = "BWP $max"
            
            updateFooterText()
        }

        binding.switchSmartAlerts.setOnCheckedChangeListener { _, isChecked ->
            binding.tvLimitBadge.visibility = if (isChecked) View.VISIBLE else View.GONE
            updateFooterText()
        }
    }

    private fun updateFooterText() {
        val maxPrice = binding.budgetSlider.values[1].toInt()
        val isChecked = binding.switchSmartAlerts.isChecked
        val areas = if (selectedLocations.isEmpty()) "anywhere" else selectedLocations.joinToString(", ")

        if (isChecked) {
            binding.tvMatchingAlertFooter.text = "Matching listings in $areas under P $maxPrice will trigger a ping"
        } else {
            binding.tvMatchingAlertFooter.text = "Smart alerts are currently disabled."
        }
    }

    private fun savePreferences() {
        val database = AppDatabase.getDatabase(requireContext())
        val minPrice = binding.budgetSlider.values[0].toInt()
        val maxPrice = binding.budgetSlider.values[1].toInt()
        val moveInDate = binding.tvMoveInDate.text.toString()
        val locationsStr = selectedLocations.joinToString(",")
        val isAlertEnabled = binding.switchSmartAlerts.isChecked

        if (MainActivity.currentUserId == -1) {
            Toast.makeText(context, "Guest settings saved for session", Toast.LENGTH_SHORT).show()
            findNavController().navigateUp()
            return
        }

        val user = currentUser
        if (user != null) {
            val updatedUser = user.copy(
                budgetMin = minPrice,
                budgetMax = maxPrice,
                preferredLocations = locationsStr,
                moveInDate = moveInDate,
                smartAlertsEnabled = isAlertEnabled
            )

            CoroutineScope(Dispatchers.IO).launch {
                database.userDao().updateUser(updatedUser)
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Preferences saved successfully!", Toast.LENGTH_SHORT).show()
                    findNavController().navigateUp()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
