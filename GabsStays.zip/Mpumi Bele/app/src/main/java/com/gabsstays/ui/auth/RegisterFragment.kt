package com.gabsstays.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.User
import com.gabsstays.databinding.FragmentRegisterBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    private var selectedRole = "Student" // Default role

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val database = AppDatabase.getDatabase(requireContext())

        // Dynamically load current student count and update "Spots Left" notice
        CoroutineScope(Dispatchers.IO).launch {
            val studentCount = database.userDao().getStudentsCount()
            val spotsLeft = (50 - studentCount).coerceAtLeast(0)
            withContext(Dispatchers.Main) {
                binding.tvSpotsBadge.text = "Limited Capacity Phase ($spotsLeft/50 Spots Left)"
            }
        }

        // Student Role Selection clicked
        binding.btnRoleStudent.setOnClickListener {
            selectedRole = "Student"
            binding.btnRoleStudent.setBackgroundResource(R.drawable.bg_role_selected)
            binding.btnRoleProvider.setBackgroundResource(R.drawable.bg_role_unselected)
            binding.tvRoleStudentLbl.setTextColor(resources.getColor(R.color.primary_dark, null))
            binding.tvRoleProviderLbl.setTextColor(resources.getColor(R.color.text_secondary, null))
            
            // Show student fields
            binding.tvRegIdLabel.visibility = View.VISIBLE
            binding.tilRegId.visibility = View.VISIBLE
        }

        // Provider Role Selection clicked
        binding.btnRoleProvider.setOnClickListener {
            selectedRole = "Provider"
            binding.btnRoleProvider.setBackgroundResource(R.drawable.bg_role_selected)
            binding.btnRoleStudent.setBackgroundResource(R.drawable.bg_role_unselected)
            binding.tvRoleProviderLbl.setTextColor(resources.getColor(R.color.primary_dark, null))
            binding.tvRoleStudentLbl.setTextColor(resources.getColor(R.color.text_secondary, null))
            
            // Hide student ID fields
            binding.tvRegIdLabel.visibility = View.GONE
            binding.tilRegId.visibility = View.GONE
        }

        binding.btnRegister.setOnClickListener {
            val name = binding.etRegName.text.toString().trim()
            val email = binding.etRegEmail.text.toString().trim()
            val password = binding.etRegPassword.text.toString().trim()
            val studentId = if (selectedRole == "Student") binding.etRegId.text.toString().trim() else null

            // Validations
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(context, "Please fill in all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedRole == "Student" && studentId.isNullOrEmpty()) {
                Toast.makeText(context, "Student ID Number is required for students", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            CoroutineScope(Dispatchers.IO).launch {
                val existingUser = database.userDao().getUserByEmail(email)
                val currentStudents = database.userDao().getStudentsCount()

                withContext(Dispatchers.Main) {
                    if (existingUser != null) {
                        Toast.makeText(context, "An account with this email already exists", Toast.LENGTH_SHORT).show()
                        return@withContext
                    }

                    if (selectedRole == "Student" && currentStudents >= 50) {
                        Toast.makeText(context, "Cannot register. The 50 student limit has been reached.", Toast.LENGTH_LONG).show()
                        return@withContext
                    }

                    // Create and insert user
                    val newUser = User(
                        fullName = name,
                        role = selectedRole,
                        studentId = studentId,
                        email = email,
                        password = password
                    )

                    CoroutineScope(Dispatchers.IO).launch {
                        database.userDao().insertUser(newUser)
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Account created successfully! Please login.", Toast.LENGTH_LONG).show()
                            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
                        }
                    }
                }
            }
        }

        binding.btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.tvLoginLink.setOnClickListener {
            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
