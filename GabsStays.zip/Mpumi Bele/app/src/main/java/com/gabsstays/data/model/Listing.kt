package com.gabsstays.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val price: Int, // Monthly rent in BWP
    val location: String, // Gaborone area (e.g., Tlokweng, G-West, Phase 2, etc.)
    val type: String, // Single Room (En-suite), Shared Apartment, Bedsitter, Cottage, etc.
    val amenities: String, // Comma-separated (WiFi, AC, Parking, Hot Water, etc.)
    val availabilityDate: String, // yyyy-MM-dd format
    val depositAmount: Int, // in BWP
    val status: String = "Available", // "Available" or "Reserved"
    val imageUrl: String? = null, // Simulated image code (e.g., drawable resource identifier or color)
    val providerId: Int = 0 // Landlord user id
)
