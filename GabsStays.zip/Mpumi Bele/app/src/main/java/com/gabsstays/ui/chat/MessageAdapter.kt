package com.gabsstays.ui.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gabsstays.data.model.ChatMessage
import com.gabsstays.databinding.ItemMessageBinding
import com.gabsstays.ui.MainActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    private var messageList = listOf<ChatMessage>()

    fun submitList(list: List<ChatMessage>) {
        messageList = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemMessageBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return MessageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        holder.bind(messageList[position])
    }

    override fun getItemCount(): Int = messageList.size

    inner class MessageViewHolder(private val binding: ItemMessageBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(message: ChatMessage) {
            val sdf = SimpleDateFormat("HH:mm a", Locale.getDefault())
            val formattedTime = sdf.format(Date(message.timestamp))

            if (message.senderId == MainActivity.currentUserId) {
                // Outgoing message (Right Aligned)
                binding.containerOutgoing.visibility = View.VISIBLE
                binding.containerIncoming.visibility = View.GONE
                
                binding.tvTextOutgoing.text = message.messageText
                binding.tvTimeOutgoing.text = formattedTime
            } else {
                // Incoming message (Left Aligned)
                binding.containerIncoming.visibility = View.VISIBLE
                binding.containerOutgoing.visibility = View.GONE
                
                binding.tvTextIncoming.text = message.messageText
                binding.tvTimeIncoming.text = formattedTime
            }
        }
    }
}
