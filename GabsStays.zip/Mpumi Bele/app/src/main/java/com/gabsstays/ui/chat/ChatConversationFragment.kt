package com.gabsstays.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.ChatMessage
import com.gabsstays.databinding.FragmentChatConversationBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date

class ChatConversationFragment : Fragment() {

    private var _binding: FragmentChatConversationBinding? = null
    private val binding get() = _binding!!

    private var listingId: Int = -1
    private var landlordId: Int = -1
    private lateinit var adapter: MessageAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatConversationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listingId = arguments?.getInt("listingId") ?: -1
        landlordId = arguments?.getInt("landlordId") ?: -1

        adapter = MessageAdapter()
        binding.rvMessages.layoutManager = LinearLayoutManager(context).apply {
            stackFromEnd = true // Scroll to bottom when keyboard opens
        }
        binding.rvMessages.adapter = adapter

        binding.btnChatBack.setOnClickListener {
            findNavController().navigateUp()
        }

        binding.btnSendMessage.setOnClickListener {
            sendMessage()
        }

        loadHeaderAndMessages()
    }

    private fun loadHeaderAndMessages() {
        val database = AppDatabase.getDatabase(requireContext())
        CoroutineScope(Dispatchers.IO).launch {
            val listing = database.listingDao().getListingById(listingId)
            val landlord = database.userDao().getUserById(landlordId)

            withContext(Dispatchers.Main) {
                if (landlord != null) {
                    binding.tvChatLandlordName.text = landlord.fullName
                }
                if (listing != null) {
                    binding.tvChatPropertyTitle.text = listing.title
                }
            }

            // Load message list
            refreshMessages()
        }
    }

    private fun refreshMessages() {
        val database = AppDatabase.getDatabase(requireContext())
        val currentUserId = MainActivity.currentUserId
        
        CoroutineScope(Dispatchers.IO).launch {
            val messages = database.chatDao().getMessagesInConversation(
                currentUserId, landlordId, listingId
            )
            withContext(Dispatchers.Main) {
                adapter.submitList(messages)
                if (messages.isNotEmpty()) {
                    binding.rvMessages.scrollToPosition(messages.size - 1)
                }
            }
        }
    }

    private fun sendMessage() {
        val messageText = binding.etMessage.text.toString().trim()
        if (messageText.isEmpty()) return

        val database = AppDatabase.getDatabase(requireContext())
        val currentUserId = MainActivity.currentUserId
        val textToSend = messageText

        binding.etMessage.text.clear()

        CoroutineScope(Dispatchers.IO).launch {
            // Write outgoing message
            val message = ChatMessage(
                senderId = currentUserId,
                receiverId = landlordId,
                listingId = listingId,
                messageText = textToSend,
                timestamp = Date().time
            )
            database.chatDao().insertMessage(message)

            // Refresh UI
            refreshMessages()

            // Wait 1.5 seconds and trigger simulated landlord response!
            delay(1500)
            
            // Get landlord name to personalize
            val landlord = database.userDao().getUserById(landlordId)
            val landlordName = landlord?.fullName ?: "Landlord"
            val listing = database.listingDao().getListingById(listingId)
            val isReserved = listing?.status == "Reserved"

            val replyText = if (isReserved) {
                "Hello! Thank you for the reservation payment. I received the deposit confirmation for '${listing?.title}'. Let's finalize your move-in date. When are you planning to arrive?"
            } else {
                "Hi there! Yes, the room at '${listing?.title}' is still available. You can view it this week. Let me know what date works best for you!"
            }

            val simulatedReply = ChatMessage(
                senderId = landlordId,
                receiverId = currentUserId,
                listingId = listingId,
                messageText = replyText,
                timestamp = Date().time
            )
            database.chatDao().insertMessage(simulatedReply)

            withContext(Dispatchers.Main) {
                refreshMessages()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
