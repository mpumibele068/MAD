package com.gabsstays.ui.listings

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.Listing
import com.gabsstays.data.model.Reservation
import com.gabsstays.data.model.User
import com.gabsstays.databinding.FragmentDetailsBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DetailsFragment : Fragment() {

    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!

    private var listingId: Int = -1
    private var currentListing: Listing? = null
    private var landlord: User? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listingId = arguments?.getInt("listingId") ?: -1

        binding.btnDetailBack.setOnClickListener {
            findNavController().navigateUp()
        }

        loadListingData()
    }

    private fun loadListingData() {
        val database = AppDatabase.getDatabase(requireContext())
        CoroutineScope(Dispatchers.IO).launch {
            val listing = database.listingDao().getListingById(listingId)
            currentListing = listing

            if (listing != null) {
                landlord = database.userDao().getUserById(listing.providerId)
            }

            withContext(Dispatchers.Main) {
                bindListingDetails()
            }
        }
    }

    private fun bindListingDetails() {
        val listing = currentListing ?: return
        val landlordUser = landlord

        binding.tvDetailTitle.text = listing.title
        binding.tvDetailLocation.text = "${listing.location}, Gaborone"
        binding.tvDetailPrice.text = "P ${String.format("%,d", listing.price)}"
        binding.tvDetailDeposit.text = "P ${String.format("%,d", listing.depositAmount)}"

        binding.tvDetailTypeRow.text = "• Room Type: ${listing.type}"
        binding.tvDetailDateRow.text = "• Available From: ${listing.availabilityDate}"
        binding.tvDetailAmenitiesRow.text = "• Amenities: ${listing.amenities.replace(",", ", ")}"

        if (landlordUser != null) {
            binding.tvLandlordName.text = landlordUser.fullName
            binding.tvLandlordEmail.text = landlordUser.email
        }

        if (listing.status == "Reserved") {
            binding.tvDetailStatus.text = "Reserved"
            binding.tvDetailStatus.setBackgroundResource(R.drawable.bg_rounded_card)
            binding.tvDetailStatus.background.setTint(Color.parseColor("#FF1744"))
            binding.tvDetailStatus.setTextColor(Color.WHITE)

            binding.btnPayDeposit.text = "Reserved - Booking Closed"
            binding.btnPayDeposit.isEnabled = false
            binding.btnPayDeposit.setBackgroundColor(
                ContextCompat.getColor(requireContext(), R.color.text_muted)
            )
        } else {
            binding.tvDetailStatus.text = "Available"
            binding.tvDetailStatus.setBackgroundResource(R.drawable.bg_role_selected)
            binding.tvDetailStatus.background.setTint(Color.parseColor("#E0F7FA"))
            binding.tvDetailStatus.setTextColor(
                ContextCompat.getColor(requireContext(), R.color.primary_dark)
            )

            binding.btnPayDeposit.text = "Reserve & Pay Deposit"
            binding.btnPayDeposit.isEnabled = true
            binding.btnPayDeposit.setOnClickListener {
                if (MainActivity.currentUserId == -1) {
                    Toast.makeText(
                        context,
                        "Guests cannot make reservations. Please log in.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    showPaymentDialog(listing)
                }
            }
        }

        binding.btnMessageLandlordDetail.setOnClickListener {
            if (MainActivity.currentUserId == -1) {
                Toast.makeText(
                    context,
                    "Guests cannot message landlords. Please log in.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                val bundle = bundleOf(
                    "listingId" to listing.id,
                    "landlordId" to listing.providerId
                )
                findNavController().navigate(
                    R.id.action_detailsFragment_to_chatConversationFragment, bundle
                )
            }
        }
    }

    private fun showPaymentDialog(listing: Listing) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_payment, null)
        val tvDesc = dialogView.findViewById<TextView>(R.id.tv_payment_desc)
        val etPin = dialogView.findViewById<EditText>(R.id.et_payment_pin)

        tvDesc.text = "Enter your simulated 4-digit Mobile Money PIN to authorize a deposit " +
                "payment of P ${String.format("%,d", listing.depositAmount)}.00."

        val alertDialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        dialogView.findViewById<View>(R.id.btn_cancel_payment).setOnClickListener {
            alertDialog.dismiss()
        }

        dialogView.findViewById<View>(R.id.btn_confirm_payment).setOnClickListener {
            val pin = etPin.text.toString().trim()
            if (pin.length < 4) {
                Toast.makeText(context, "Please enter a valid 4-digit PIN", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            alertDialog.dismiss()
            processSimulatedPayment(listing)
        }

        alertDialog.show()
    }

    private fun processSimulatedPayment(listing: Listing) {
        val database = AppDatabase.getDatabase(requireContext())

        CoroutineScope(Dispatchers.IO).launch {
            // Update listing status using full updateListing (no custom query needed)
            val updatedListing = listing.copy(status = "Reserved")
            database.listingDao().updateListing(updatedListing)

            // Build Reservation with correct field names
            val referenceCode = "GABS-${(1000..9999).random()}-STAY"
            val timeStamp = SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault())
                .format(Date())

            val reservation = Reservation(
                studentId = MainActivity.currentUserId,
                listingId = listing.id,
                referenceNumber = referenceCode,
                paymentMethod = "Simulated Mobile Money",
                transactionTime = timeStamp,
                totalPaid = listing.depositAmount
            )
            val newReservationId = database.reservationDao()
                .insertReservation(reservation).toInt()

            withContext(Dispatchers.Main) {
                Toast.makeText(
                    context,
                    "Payment Successful! Reservation Confirmed.",
                    Toast.LENGTH_LONG
                ).show()
                val bundle = bundleOf("reservationId" to newReservationId)
                findNavController().navigate(
                    R.id.action_detailsFragment_to_confirmationFragment, bundle
                )
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
