package com.gabsstays.ui.payment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.Listing
import com.gabsstays.data.model.Reservation
import com.gabsstays.databinding.FragmentConfirmationBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ConfirmationFragment : Fragment() {

    private var _binding: FragmentConfirmationBinding? = null
    private val binding get() = _binding!!

    private var reservationId: Int = -1
    private var reservation: Reservation? = null
    private var listing: Listing? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentConfirmationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        reservationId = arguments?.getInt("reservationId") ?: -1

        binding.btnBackDashboard.setOnClickListener {
            findNavController().navigate(R.id.action_confirmationFragment_to_listingsFragment)
        }

        binding.btnDlReceipt.setOnClickListener {
            val ref = reservation?.referenceNumber ?: "RECEIPT"
            Toast.makeText(context, "Receipt PDF saved to Downloads ($ref.pdf)", Toast.LENGTH_LONG).show()
        }

        binding.btnShareReceipt.setOnClickListener {
            Toast.makeText(context, "Receipt shared successfully!", Toast.LENGTH_SHORT).show()
        }

        loadReceiptData()
    }

    private fun loadReceiptData() {
        val database = AppDatabase.getDatabase(requireContext())
        CoroutineScope(Dispatchers.IO).launch {
            val res = database.reservationDao().getReservationById(reservationId)
            reservation = res

            if (res != null) {
                listing = database.listingDao().getListingById(res.listingId)
            }

            withContext(Dispatchers.Main) {
                bindReceiptDetails()
            }
        }
    }

    private fun bindReceiptDetails() {
        val res = reservation ?: return
        val list = listing ?: return

        binding.tvReceiptId.text = res.referenceNumber
        binding.tvReceiptTitle.text = list.title
        binding.tvReceiptLocation.text = "${list.location}, Gaborone"
        binding.tvReceiptType.text = list.type
        binding.tvReceiptIntake.text = "August 2024 Intake"

        // transactionTime is already a formatted string (e.g. "May 21, 2026 02:26 PM")
        binding.tvReceiptTime.text = res.transactionTime

        // totalPaid holds the deposit amount in BWP
        binding.tvReceiptTotal.text = "P ${String.format("%,d", res.totalPaid)}.00"

        // Message landlord button — use providerId from Listing
        binding.btnMessageLandlordReceipt.setOnClickListener {
            val bundle = bundleOf(
                "listingId" to list.id,
                "landlordId" to list.providerId
            )
            findNavController().navigate(
                R.id.action_confirmationFragment_to_chatConversationFragment, bundle
            )
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
