package com.gabsstays.data

import android.content.Context
import android.util.Log
import com.gabsstays.data.model.ChatMessage
import com.gabsstays.data.model.Listing
import com.gabsstays.data.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.random.Random

object DatabaseSeeder {

    private const val TAG = "DatabaseSeeder"

    fun seedDatabaseIfEmpty(context: Context, database: AppDatabase) {
        CoroutineScope(Dispatchers.IO).launch {
            val userDao = database.userDao()
            val listingDao = database.listingDao()
            val chatDao = database.chatDao()

            val studentCount = userDao.getStudentsCount()
            val listingsCount = listingDao.getListingsCount()

            Log.d(TAG, "Checking database. Students: $studentCount, Listings: $listingsCount")

            // 1. Seed Students if empty
            if (studentCount == 0) {
                val students = mutableListOf<User>()
                
                // Add a primary test student account with easy credentials
                students.add(
                    User(
                        fullName = "Kgosi Motsumi",
                        role = "Student",
                        studentId = "202400123",
                        email = "kgosi@ub.ac.bw",
                        password = "password",
                        budgetMin = 1200,
                        budgetMax = 3500,
                        preferredLocations = "Tlokweng,G-West",
                        moveInDate = "2024-08-01",
                        smartAlertsEnabled = true
                    )
                )

                // Add 49 more student records (Total 50)
                val firstNames = listOf("Mpho", "Thabo", "Kabo", "Lesedi", "Refilwe", "Tshepo", "Neo", "Katlego", "Oaitse", "Botho", "Goitseone", "Lefika", "Tumelo", "Kaelo", "Wame")
                val lastNames = listOf("Motsumi", "Molefe", "Sebabole", "Phiri", "Ntuane", "Tafa", "Balopi", "Kebalatse", "Letsholo", "Dube", "Sello", "Mooketsi", "Sebele", "Tshosa", "Pilane")
                
                for (i in 2..50) {
                    val firstName = firstNames[(i) % firstNames.size]
                    val lastName = lastNames[(i + 3) % lastNames.size]
                    val fullName = "$firstName $lastName"
                    val idNum = "2024${10000 + i}"
                    val email = "${firstName.lowercase()}${i}@ub.ac.bw"
                    
                    students.add(
                        User(
                            fullName = fullName,
                            role = "Student",
                            studentId = idNum,
                            email = email,
                            password = "password$i",
                            budgetMin = 1000 + (Random.nextInt(5) * 200),
                            budgetMax = 2500 + (Random.nextInt(5) * 300),
                            preferredLocations = listOf("Tlokweng", "G-West", "Phase 2", "Village").shuffled().take(2).joinToString(","),
                            moveInDate = "2024-08-${String.format("%02d", (Random.nextInt(28) + 1))}",
                            smartAlertsEnabled = i % 2 == 0
                        )
                    )
                }

                // Seed some Landlords (Providers) so students have landlords to chat with
                val landlords = listOf(
                    User(fullName = "Mr. Mpumi Bele", role = "Provider", studentId = null, email = "mpumi@gabsstays.co.bw", password = "password"),
                    User(fullName = "Mrs. Keletso Phiri", role = "Provider", studentId = null, email = "keletso@gabsstays.co.bw", password = "password"),
                    User(fullName = "Lame Lekoko", role = "Provider", studentId = null, email = "lame@gabsstays.co.bw", password = "password"),
                    User(fullName = "Bakang Moeti", role = "Provider", studentId = null, email = "bakang@gabsstays.co.bw", password = "password"),
                    User(fullName = "Thabiso Balopi", role = "Provider", studentId = null, email = "thabiso@gabsstays.co.bw", password = "password")
                )

                userDao.insertUsers(students)
                userDao.insertUsers(landlords)
                Log.d(TAG, "Seeded 50 students and 5 landlords.")
            }

            // 2. Seed 50 Listings if empty
            if (listingsCount == 0) {
                // Get landlord user IDs to associate with listings
                val dbUsers = userDao.getAllUsers()
                val providerIds = dbUsers.filter { it.role == "Provider" }.map { it.id }.ifEmpty { listOf(1) }

                val locations = listOf("Tlokweng", "G-West", "Phase 2", "Village", "Broadhurst", "Block 6", "Mmaraka", "Notwane")
                val listingTypes = listOf("Single Room (En-suite)", "Shared Apartment", "Bedsitter", "Cottage", "Double Room (Shared)")
                val titles = listOf(
                    "Student Villa", "Cozy Nest", "Secure Bedsitter", "Modern Flat", 
                    "Spacious Cottage", "Comfort Stay", "Premium Ensuite", "Budget Room",
                    "Academics Hub", "Scholars Retreat", "Executive Room", "Standard Cottage"
                )
                
                val amenitiesList = listOf(
                    "WiFi, AC, Parking, Hot Water, Gated",
                    "WiFi, Shared Kitchen, Laundry, Secure",
                    "WiFi, Parking, Near Bus Stop, Solar Backup",
                    "WiFi, Hot Water, Study Desk, Gated Yard",
                    "WiFi, Aircon, Electric Fence, Parking",
                    "Shared Kitchen, High Security, Study Desk"
                )

                val listings = mutableListOf<Listing>()
                for (i in 1..50) {
                    val location = locations[i % locations.size]
                    val type = listingTypes[(i * 3) % listingTypes.size]
                    val titlePrefix = titles[(i * 7) % titles.size]
                    val title = "$location $titlePrefix #$i"
                    
                    val price = 1200 + ((i % 12) * 200) // Ranges from P1200 to P3400
                    val deposit = price - 200 // Slightly less than monthly rent
                    val amenities = amenitiesList[i % amenitiesList.size]
                    val providerId = providerIds[i % providerIds.size]
                    
                    // Availability date format: yyyy-MM-dd
                    val availabilityDate = "2024-08-${String.format("%02d", (i % 28) + 1)}"

                    listings.add(
                        Listing(
                            title = title,
                            price = price,
                            location = location,
                            type = type,
                            amenities = amenities,
                            availabilityDate = availabilityDate,
                            depositAmount = deposit,
                            status = "Available",
                            imageUrl = "property_img_${(i % 5) + 1}",
                            providerId = providerId
                        )
                    )
                }

                listingDao.insertListings(listings)
                Log.d(TAG, "Seeded 50 listings.")

                // Seed some initial chat messages to start with some content
                val dbListings = listingDao.getAllListings()
                val students = userDao.getAllUsers().filter { it.role == "Student" }
                
                if (students.isNotEmpty() && dbListings.isNotEmpty()) {
                    val sampleStudent = students.first()
                    val sampleListing = dbListings.first()
                    val landlordId = sampleListing.providerId

                    val messages = listOf(
                        ChatMessage(
                            listingId = sampleListing.id,
                            senderId = sampleStudent.id,
                            receiverId = landlordId,
                            messageText = "Hello landlord! Is the room in Broadhurst still available for the August intake?",
                            timestamp = System.currentTimeMillis() - 3600000 * 2 // 2 hours ago
                        ),
                        ChatMessage(
                            listingId = sampleListing.id,
                            senderId = landlordId,
                            receiverId = sampleStudent.id,
                            messageText = "Yes, it is still available. You can view the details and reserve it by paying the deposit.",
                            timestamp = System.currentTimeMillis() - 3600000 // 1 hour ago
                        )
                    )
                    chatDao.insertMessages(messages)
                    Log.d(TAG, "Seeded sample chat messages.")
                }
            }
        }
    }
}
