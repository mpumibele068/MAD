package com.gabsstays.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.gabsstays.data.model.ChatMessage

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMessage(message: ChatMessage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertMessages(messages: List<ChatMessage>)

    @Query("SELECT * FROM chat_messages WHERE listingId = :listingId ORDER BY timestamp ASC")
    fun getMessagesForListing(listingId: Int): List<ChatMessage>

    @Query("SELECT * FROM chat_messages WHERE (senderId = :userId OR receiverId = :userId) ORDER BY timestamp DESC")
    fun getAllMessagesForUser(userId: Int): List<ChatMessage>

    @Query("SELECT * FROM chat_messages WHERE listingId = :listingId AND ((senderId = :userId AND receiverId = :otherUserId) OR (senderId = :otherUserId AND receiverId = :userId)) ORDER BY timestamp ASC")
    fun getMessagesInConversation(userId: Int, otherUserId: Int, listingId: Int): List<ChatMessage>

    @Query("SELECT * FROM chat_messages WHERE (senderId = :userId OR receiverId = :userId) ORDER BY timestamp DESC")
    fun getMessagesForUser(userId: Int): List<ChatMessage>
}
