package com.gabsstays.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.DatabaseSeeder
import com.gabsstays.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    companion object {
        // Simple static storage for the currently logged-in user
        var currentUserId: Int = -1
        var currentUserRole: String = "Student"
        var currentUserName: String = "Guest"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Seed database with 50 students, 5 landlords and 50 properties on launch
        val database = AppDatabase.getDatabase(this)
        DatabaseSeeder.seedDatabaseIfEmpty(this, database)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        // Set up bottom navigation with navController
        binding.bottomNav.setupWithNavController(navController)

        // Control bottom navigation bar visibility based on screen destination
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.listingsFragment, R.id.chatListFragment -> {
                    binding.bottomNav.visibility = View.VISIBLE
                }
                else -> {
                    binding.bottomNav.visibility = View.GONE
                }
            }
        }
    }
}
