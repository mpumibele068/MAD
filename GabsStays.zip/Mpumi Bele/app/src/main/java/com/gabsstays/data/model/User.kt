package com.gabsstays.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fullName: String,
    val role: String, // "Student" or "Provider"
    val studentId: String?, // Only applicable for Student
    val email: String,
    val password: String,
    
    // User preferences for filters & alerts
    val budgetMin: Int = 1200,
    val budgetMax: Int = 3500,
    val preferredLocations: String = "Tlokweng,G-West", // Comma-separated Gaborone areas
    val moveInDate: String = "2024-08-01",
    val smartAlertsEnabled: Boolean = true
)
