package com.gabsstays.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.databinding.FragmentChatListBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatListFragment : Fragment() {

    private var _binding: FragmentChatListBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ChatRoomAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChatListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ChatRoomAdapter { room ->
            val bundle = bundleOf(
                "listingId" to room.listingId,
                "landlordId" to room.landlordId
            )
            findNavController().navigate(R.id.action_chatListFragment_to_chatConversationFragment, bundle)
        }

        binding.rvChatRooms.layoutManager = LinearLayoutManager(context)
        binding.rvChatRooms.adapter = adapter

        loadChatRooms()
    }

    private fun loadChatRooms() {
        val currentUserId = MainActivity.currentUserId
        if (currentUserId == -1) {
            // Guest mode
            binding.tvEmptyChats.text = "Please log in to chat with landlords."
            binding.tvEmptyChats.visibility = View.VISIBLE
            binding.rvChatRooms.visibility = View.GONE
            return
        }

        val database = AppDatabase.getDatabase(requireContext())
        CoroutineScope(Dispatchers.IO).launch {
            // Get all messages for user
            val messages = database.chatDao().getMessagesForUser(currentUserId)
            
            // Fetch reservations (if a user has a reserved listing, ensure they see a chat room for it, even if no messages are sent yet!)
            val reservations = database.reservationDao().getReservationsForStudent(currentUserId)

            val roomsMap = mutableMapOf<Int, ChatRoom>()

            // 1. Process existing messages into chat rooms
            for (msg in messages) {
                val listingId = msg.listingId
                if (!roomsMap.containsKey(listingId)) {
                    val listing = database.listingDao().getListingById(listingId)
                    if (listing != null) {
                    val landlordId = listing.providerId
                        val landlord = database.userDao().getUserById(landlordId)
                        val name = landlord?.fullName ?: "Landlord"

                        // Get last message in this room
                        val roomMessages = messages.filter { it.listingId == listingId }
                        val lastMsg = roomMessages.maxByOrNull { it.timestamp }
                        
                        if (lastMsg != null) {
                            roomsMap[listingId] = ChatRoom(
                                listingId = listingId,
                                landlordId = landlordId,
                                landlordName = name,
                                propertyTitle = listing.title,
                                lastMessageText = lastMsg.messageText,
                                timestamp = lastMsg.timestamp
                            )
                        }
                    }
                }
            }

            // 2. Add reserved listings as rooms (even if no messages exist yet)
            for (res in reservations) {
                if (!roomsMap.containsKey(res.listingId)) {
                    val listing = database.listingDao().getListingById(res.listingId)
                    if (listing != null) {
                        val landlord = database.userDao().getUserById(listing.providerId)
                        val name = landlord?.fullName ?: "Landlord"

                        roomsMap[res.listingId] = ChatRoom(
                            listingId = res.listingId,
                            landlordId = listing.providerId,
                            landlordName = name,
                            propertyTitle = listing.title,
                            lastMessageText = "Start chatting to arrange move-in date!",
                            timestamp = System.currentTimeMillis()
                        )
                    }
                }
            }

            val finalRooms = roomsMap.values.sortedByDescending { it.timestamp }

            withContext(Dispatchers.Main) {
                if (finalRooms.isEmpty()) {
                    binding.tvEmptyChats.visibility = View.VISIBLE
                    binding.rvChatRooms.visibility = View.GONE
                } else {
                    binding.tvEmptyChats.visibility = View.GONE
                    binding.rvChatRooms.visibility = View.VISIBLE
                    adapter.submitList(finalRooms)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
