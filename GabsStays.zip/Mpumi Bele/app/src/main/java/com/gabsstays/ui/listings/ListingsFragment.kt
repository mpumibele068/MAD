package com.gabsstays.ui.listings

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.app.NotificationCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.gabsstays.R
import com.gabsstays.data.AppDatabase
import com.gabsstays.data.model.Listing
import com.gabsstays.data.model.User
import com.gabsstays.databinding.FragmentListingsBinding
import com.gabsstays.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ListingsFragment : Fragment() {

    private var _binding: FragmentListingsBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ListingAdapter
    private var allListings = listOf<Listing>()
    private var currentUser: User? = null

    companion object {
        private const val CHANNEL_ID = "gabsstays_alerts_channel"
        private const val NOTIFICATION_ID = 101
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentListingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup UI information based on user
        binding.tvUserBadge.text = MainActivity.currentUserRole
        if (MainActivity.currentUserRole == "Guest") {
            binding.tvUserBadge.setBackgroundResource(R.drawable.bg_rounded_card)
        }

        // Setup Recycler View
        adapter = ListingAdapter { listing ->
            val bundle = bundleOf("listingId" to listing.id)
            findNavController().navigate(R.id.action_listingsFragment_to_detailsFragment, bundle)
        }
        binding.rvListings.layoutManager = LinearLayoutManager(context)
        binding.rvListings.adapter = adapter

        // Setup listeners
        binding.btnFilter.setOnClickListener {
            findNavController().navigate(R.id.action_listingsFragment_to_filtersFragment)
        }

        binding.btnClearFilters.setOnClickListener {
            // Disable filters for this session view
            binding.bannerFilters.visibility = View.GONE
            adapter.submitList(allListings)
            binding.tvEmptyState.visibility = if (allListings.isEmpty()) View.VISIBLE else View.GONE
        }

        // Search text watcher simulation (search on type/click)
        binding.etSearch.setOnKeyListener { _, _, _ ->
            performSearch(binding.etSearch.text.toString().trim())
            false
        }

        loadData()
    }

    private fun loadData() {
        val database = AppDatabase.getDatabase(requireContext())

        CoroutineScope(Dispatchers.IO).launch {
            // Fetch all listings
            allListings = database.listingDao().getAllListings()

            // Fetch user profile preferences
            if (MainActivity.currentUserId != -1) {
                currentUser = database.userDao().getUserById(MainActivity.currentUserId)
            }

            withContext(Dispatchers.Main) {
                applyFilters()
            }
        }
    }

    private fun applyFilters() {
        val user = currentUser
        if (user == null || MainActivity.currentUserId == -1) {
            // Guest mode: no saved filters by default, show all
            binding.bannerFilters.visibility = View.GONE
            adapter.submitList(allListings)
            binding.tvEmptyState.visibility = if (allListings.isEmpty()) View.VISIBLE else View.GONE
            return
        }

        // Student mode: apply preference filters
        val locations = user.preferredLocations.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val minPrice = user.budgetMin
        val maxPrice = user.budgetMax

        // Filter listings based on budget, locations
        val filteredListings = allListings.filter { listing ->
            val matchesPrice = listing.price in minPrice..maxPrice
            val matchesLocation = locations.isEmpty() || locations.contains(listing.location.lowercase())
            matchesPrice && matchesLocation
        }

        // Set banner details
        binding.bannerFilters.visibility = View.VISIBLE
        binding.tvFilterSummary.text = "Filters: ${user.preferredLocations} | P$minPrice - P$maxPrice"

        adapter.submitList(filteredListings)
        binding.tvEmptyState.visibility = if (filteredListings.isEmpty()) View.VISIBLE else View.GONE

        // Fire Smart Alerts Notification if enabled and matches exist
        if (user.smartAlertsEnabled && filteredListings.isNotEmpty()) {
            triggerLocalAlert(filteredListings.size, user.preferredLocations, maxPrice)
        }
    }

    private fun performSearch(query: String) {
        if (query.isEmpty()) {
            applyFilters()
            return
        }
        val searchResults = allListings.filter {
            it.title.lowercase().contains(query.lowercase()) ||
            it.location.lowercase().contains(query.lowercase()) ||
            it.type.lowercase().contains(query.lowercase())
        }
        adapter.submitList(searchResults)
        binding.bannerFilters.visibility = View.GONE
        binding.tvEmptyState.visibility = if (searchResults.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun triggerLocalAlert(matchesCount: Int, areas: String, maxPrice: Int) {
        val context = context ?: return
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create Channel for Android Oreo (API 26) and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "GabsStays Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Smart matching notifications for student accommodation preferences."
            }
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GabsStays Smart Match!")
            .setContentText("Found $matchesCount properties matching your budget under P$maxPrice in $areas.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
