package com.gabsstays.ui.listings

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.gabsstays.R
import com.gabsstays.data.model.Listing
import com.gabsstays.databinding.ItemListingBinding

class ListingAdapter(private val onClick: (Listing) -> Unit) :
    RecyclerView.Adapter<ListingAdapter.ListingViewHolder>() {

    private var listingsList = listOf<Listing>()

    fun submitList(list: List<Listing>) {
        listingsList = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListingViewHolder {
        val binding = ItemListingBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ListingViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListingViewHolder, position: Int) {
        holder.bind(listingsList[position])
    }

    override fun getItemCount(): Int = listingsList.size

    inner class ListingViewHolder(private val binding: ItemListingBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(listing: Listing) {
            binding.tvListingTitle.text = listing.title
            binding.tvListingLocation.text = "${listing.location}, Gaborone"
            binding.tvListingType.text = listing.type
            binding.tvListingAmenities.text = listing.amenities.replace(",", " • ")
            binding.tvListingDate.text = "Available: ${listing.availabilityDate}"
            binding.tvListingDeposit.text = "Deposit: P ${String.format("%,d", listing.depositAmount)}"
            binding.tvListingPrice.text = "P ${String.format("%,d", listing.price)}"

            // Apply different styles based on status (Available vs. Reserved)
            if (listing.status == "Reserved") {
                binding.tvStatusBadge.text = "Reserved"
                binding.tvStatusBadge.setBackgroundResource(R.drawable.bg_rounded_card)
                binding.tvStatusBadge.background.setTint(Color.parseColor("#FF1744")) // Solid Red
                binding.tvStatusBadge.setTextColor(Color.WHITE)
                
                binding.tvListingPrice.setTextColor(ContextCompat.getColor(itemView.context, R.color.text_secondary))
                binding.root.alpha = 0.6f
            } else {
                binding.tvStatusBadge.text = "Available"
                binding.tvStatusBadge.setBackgroundResource(R.drawable.bg_role_selected)
                binding.tvStatusBadge.background.setTint(Color.parseColor("#E0F7FA")) // Light Cyan
                binding.tvStatusBadge.setTextColor(ContextCompat.getColor(itemView.context, R.color.primary_dark))
                
                binding.tvListingPrice.setTextColor(ContextCompat.getColor(itemView.context, R.color.primary_dark))
                binding.root.alpha = 1.0f
            }

            // Bind click callback
            binding.root.setOnClickListener {
                onClick(listing)
            }
        }
    }
}
