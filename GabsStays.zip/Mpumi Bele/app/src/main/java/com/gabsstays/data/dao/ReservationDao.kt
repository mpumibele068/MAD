package com.gabsstays.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.gabsstays.data.model.Reservation

@Dao
interface ReservationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertReservation(reservation: Reservation): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertReservations(reservations: List<Reservation>)

    @Query("SELECT * FROM reservations WHERE listingId = :listingId LIMIT 1")
    fun getReservationByListing(listingId: Int): Reservation?

    @Query("SELECT * FROM reservations WHERE id = :id LIMIT 1")
    fun getReservationById(id: Int): Reservation?

    @Query("SELECT * FROM reservations WHERE studentId = :studentId ORDER BY id DESC")
    fun getReservationsForStudent(studentId: Int): List<Reservation>

    @Query("SELECT COUNT(*) FROM reservations")
    fun getReservationCount(): Int
}
